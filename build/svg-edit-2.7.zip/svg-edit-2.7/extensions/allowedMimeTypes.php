<?php

$allowedMimeTypesBySuffix = array(
    'svg' => 'image/svg+xml;charset=utf-8',
    'png' => 'image/png',
    'jpeg' => 'image/jpeg',
    'bmp' => 'image/bmp',
    'webp' => 'image/webp'
);

?>